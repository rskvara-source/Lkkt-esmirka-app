package com.example.lkktapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showBiometric()
    }

    private fun showBiometric() {
        val executor = ContextCompat.getMainExecutor(this)

        val biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    initApp()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    finish()
                }
            })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("✈️ LKKT Přístup")
            .setSubtitle("Přihlas se otiskem prstu")
            .setNegativeButtonText("Zrušit")
            .build()

        biometricPrompt.authenticate(promptInfo)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initApp() {

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL

        val refreshBtn = Button(this)
        refreshBtn.text = "🔄"

        val logoutBtn = Button(this)
        logoutBtn.text = "🚪"

        toolbar.addView(refreshBtn)
        toolbar.addView(logoutBtn)

        webView = WebView(this)

        layout.addView(toolbar)
        layout.addView(webView)

        setContentView(layout)

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true

        webView.webViewClient = WebViewClient()
        webView.loadUrl("https://lkkt.esmirka.cz")

        refreshBtn.setOnClickListener {
            webView.reload()
        }

        logoutBtn.setOnClickListener {
            val cm = CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
            webView.loadUrl("https://lkkt.esmirka.cz")
            Toast.makeText(this, "Odhlášeno", Toast.LENGTH_SHORT).show()
        }
    }
}
